﻿namespace AppExemplo1
{
    public static class Pessoa
    {
        public static string nome;
    }
}
